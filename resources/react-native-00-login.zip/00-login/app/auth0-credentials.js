module.exports = {
  clientId: "mN2foeZqhm27kVgpoeq751T2q71ASDp5",
  domain: "auth0-experiment.auth0.com"
};
